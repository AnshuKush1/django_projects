import urllib.request
import json
from django.shortcuts import render
from .models import City

def index(request):
    if request.method == 'POST':
        city_name = request.POST['city']

        # Fetch weather data from the OpenWeatherMap API
        api_key = '495042c71819dce7c7df483511f1e2ae'  # Replace with your API key
        try:
            url = f'http://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={api_key}'
            response = urllib.request.urlopen(url)
            data = json.load(response)
            weather_data = {
                'city': city_name,
                'temperature': round(data['main']['temp'] - 273.15, 2),
                'description': data['weather'][0]['description'],
            }
        except Exception as e:
            error_message = f'Error: {str(e)}'
            return render(request, 'weather_app/index.html', {'error_message': error_message})

        # Save the city to the database
        City.objects.create(name=city_name)

        return render(request, 'weather_app/index.html', {'weather_data': weather_data})

    cities = City.objects.all()
    weather_data = None
    return render(request, 'weather_app/index.html', {'cities': cities, 'weather_data': weather_data})
